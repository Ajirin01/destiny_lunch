<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-8 col-4">
                <h4 class="page-title text-center text-success">
                    <?php if(session('msg')): ?>
                    <?php echo e(session('msg')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
            </div>
            <div class="col-sm-4 col-8 text-right m-b-30">
                <a class="btn btn-primary btn-rounded float-right" href="<?php echo e(route('adverts.create')); ?>"><i class="fa fa-plus"></i> Add advert</a>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="advert grid-advert">
                    <div class="advert-info clearfix">
                        <p>Subscription Active: <span><?php echo e($advert->expired); ?></span></p>
                        <p>Status: <span><?php echo e($advert->status); ?></span></p>
                    </div>
                    <div class="advert-image" style="height: 300px">
                        <a href="<?php echo e(url('admin/adverts/'.$advert->id.'/edit')); ?>"><img style="width:350xp; height: 250px" class="img-fluid" src="<?php echo e($advert->advert); ?>" alt=""></a>
                    </div>
                    <div class="advert-info clearfix">
                        <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/advert/'.$advert->id)); ?>" method="POST" style="color: green; cursor: pointer">
                            <?php echo csrf_field(); ?>
                            <i class="fa fa-check m-r-5"></i>
                            <input style="background: transparent; border: none; color: green; cursor: pointer" type="submit" value="Activate" onclick="
                                event.stopPropagation()
                                var next = confirm('are you sure you want to delete this record?')
                                if(next){
                                    //
                                }else{
                                   event.preventDefault()
                                }
                            ">
                        </form>
                        <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/advert/'.$advert->id)); ?>" method="POST" style="color: orange; cursor: pointer">
                            <?php echo csrf_field(); ?>
                            <i class="fa fa-close"></i>
                            <input style="background: transparent; border: none; color: rgb(233, 154, 6); cursor: pointer" type="submit" value="Inactivate" onclick="
                                event.stopPropagation()
                                var next = confirm('are you sure you want to make this advert Inactive?')
                                if(next){
                                    //
                                }else{
                                   event.preventDefault()
                                }
                            ">
                            <input type="hidden" name="status" value="inactive">
                        </form>
                        <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/adverts/'.$advert->id)); ?>" method="POST" style="color: red; cursor: pointer">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <i class="fa fa-trash-o m-r-5"></i>
                            <input style="background: transparent; border: none; color: red; cursor: pointer" type="submit" value="Delete" onclick="
                                event.stopPropagation()
                                var next = confirm('are you sure you want to delete this record?')
                                if(next){
                                    //
                                }else{
                                    event.preventDefault()
                                }
                            ">
                        </form>
                        <br>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div><?php echo e($adverts->links()); ?></div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/Admin/Adverts/adverts-dashboard.blade.php ENDPATH**/ ?>