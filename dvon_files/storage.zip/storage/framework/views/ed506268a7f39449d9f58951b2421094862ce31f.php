<?php 
    define("filename", "CountryCodes.json");
	define("mode", "r");
	$ph = fopen(filename, mode);
	$json = file_get_contents(filename);
	$countries = json_decode($json, true);
?>


<?php $__env->startSection('auth_content'); ?>

<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <div class="login100-pic js-tilt" data-tilt>
                <img src="<?php echo e(asset('auth/images/img-01.png')); ?>" alt="IMG">
            </div>

            <form class="login100-form validate-form" method="GET" action="<?php echo e(route('next')); ?>">
                <?php echo csrf_field(); ?>
                <span class="login100-form-title">
                    <?php echo e(__('Register')); ?>

                </span>
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="text-danger"  role="alert">
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <div class="wrap-input100 validate-input" data-validate = "Valid first name is required: A-Za-z">
                    
                    <input class="input100 " name="fullname" value="<?php echo e(old('fullname')); ?>" required autocomplete="fullname" autofocus type="text" placeholder="fullname">

                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="wrap-input100 validate-input" data-validate = "Valid country is required: ex@abc.xyz">
                    <select class="input100" id="country" name="country" value="<?php echo e(old('country')); ?>" required autocomplete="country" autofocus placeholder="country">
                        <option value="">Please select country</option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country['dial_code']); ?>"><?php echo e($country['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" id="country_name" name="country_name" value="">
                    </select>
                    
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-globe" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="wrap-input100 validate-input" data-validate = "Password is required">
                    
                    <input class="input100 <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="phone" name="phone" required type="phone"  placeholder="phone">

                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="container-login100-form-btn">
                    <button class="login100-form-btn">
                        <?php echo e(__('Continue')); ?>

                    </button>
                </div>

                <div class="text-center p-t-136">
                    <a class="txt2" href="/register">
                        
                        
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var country = document.getElementById('country')
    var phone = document.getElementById('phone')
    var country_name_to_send = document.getElementById('country_name')
    var country_name = country.innerText
    country.onchange = ()=> {
        phone.value = country.value+" "
        country_name_to_send.value = country.options[country.selectedIndex].text
        // console.log(country_name_to_send.value)
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/auth/register.blade.php ENDPATH**/ ?>