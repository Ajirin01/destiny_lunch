<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h4 class="page-title text-center text-success">
                    <?php if(session('msg')): ?>
                    <?php echo e(session('msg')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title">Edit Article</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            <form action="<?php echo e(url('admin/blog/'.$article->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label>Article Title</label>
                        <input class="form-control" type="text" name="article_title" value="<?php echo e($article->blog_title); ?>">
                    </div>
                    <div class="form-group">
                        <label>Article Image</label>
                        <div>
                            <input class="form-control" type="file" name="article_image">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Article Description</label>
                        <textarea cols="30" rows="15" class="form-control tinymce" name="article_description" ><?php echo e($article->blog_description); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Tags <small>(separated with a comma)</small></label>
                        <input type="text" placeholder="Enter your tags" data-role="tagsinput" class="form-control" name="article_tag" value="<?php echo e($article->blog_tag); ?>">
                    </div>
                    <div class="m-t-20 text-center">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\DestinyVoiceOfNigeria\resources\views/Admin/Article/edit-article.blade.php ENDPATH**/ ?>