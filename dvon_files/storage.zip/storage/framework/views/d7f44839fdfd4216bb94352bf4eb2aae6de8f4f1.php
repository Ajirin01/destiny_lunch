<?php $__env->startSection('upper-content'); ?>
    <h1 class="text-center"><?php echo e($title); ?></h1>
    <div class="row">
        <div class="col">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/site/about.blade.php ENDPATH**/ ?>