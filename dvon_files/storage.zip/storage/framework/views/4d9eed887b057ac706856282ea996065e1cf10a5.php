<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-12">
                <h4 class="page-title">Comments</h4>
                <h4 class="page-title text-center text-success">
                    <?php if(session('success')): ?>
                    <?php echo e(session('success')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table mb-0 datatable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Comment</th>
                                <th>Status</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                function getUser($id){
                                    $user = App\User::find($id);
                                    return $user;
                                }
                            ?>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($comment->id); ?></td>
                                <td>
                                    <?php
                                        echo getUser($comment->user_id)->fullname;
                                    ?>
                                </td>
                                <td><?php echo e($comment->comment); ?></td>
                                <td><?php echo e($comment->status); ?></td>
                            <td class="text-right">
                                    <div class="dropdown dropdown-action">
                                        <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            
                                            <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/update_comment_status/'.$comment->id)); ?>" method="POST" style="color: green; cursor: pointer">
                                                <?php echo csrf_field(); ?>
                                                <i class="fa fa-check"></i>
                                                <input style="background: transparent; border: none; color: green; cursor: pointer" type="submit" value="Activate" onclick="
                                                    event.stopPropagation()
                                                    var next = confirm('are you sure you want to make this comment active?')
                                                    if(next){
                                                        //
                                                    }else{
                                                       event.preventDefault()
                                                    }
                                                ">
                                                <input type="hidden" name="status" value="active">
                                            </form>
                                            <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/update_comment_status/'.$comment->id)); ?>" method="POST" style="color: orange; cursor: pointer">
                                                <?php echo csrf_field(); ?>
                                                <i class="fa fa-close"></i>
                                                <input style="background: transparent; border: none; color: rgb(233, 154, 6); cursor: pointer" type="submit" value="Inactivate" onclick="
                                                    event.stopPropagation()
                                                    var next = confirm('are you sure you want to make this comment Inactive?')
                                                    if(next){
                                                        //
                                                    }else{
                                                       event.preventDefault()
                                                    }
                                                ">
                                                <input type="hidden" name="status" value="inactive">
                                            </form>
                                            <form class="dropdown-item" id="delete-form" action="<?php echo e(url('admin/delete_comment/'.$comment->id)); ?>" method="POST" style="color: red; cursor: pointer">
                                                <?php echo csrf_field(); ?>
                                                <i class="fa fa-trash-o m-r-5"></i>
                                                <input style="background: transparent; border: none; color: red; cursor: pointer" type="submit" value="Delete" onclick="
                                                    event.stopPropagation()
                                                    var next = confirm('are you sure you want to delete this record?')
                                                    if(next){
                                                        //
                                                    }else{
                                                       event.preventDefault()
                                                    }
                                                ">
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($comments->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/Admin/UserActionToArticle/comments-dashboard.blade.php ENDPATH**/ ?>