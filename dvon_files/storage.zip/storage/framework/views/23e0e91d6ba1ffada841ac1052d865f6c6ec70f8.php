<?php $__env->startSection('upper-content'); ?>
<div class="col-12 col-md-12">
    <div class="row">
        <div class="col-12 col-lg-5">
            <!-- Single Featured Post -->
            <h1 class="text-center">
                WELCOME
            </h1>
            <div>
                <h5 style="line-height: 1.5">
                    Welcome to Destiny Nigeria’s
                    Voice Magazine, “the
                    authentic global voice for
                    Nigeria”.
                </h5>
                <h5 style="line-height: 1.5">
                    We provide the foremost
                    platform you can rely on to
                    obtain valuable information
                    about Nigeria as a nation, her
                    people and her vast natural
                    resources.
                </h5>
                <a href="/about"><h4 class="text-center" style="font-size:0.8rem">… Read more About Us …</h4></a>
            </div>

        </div>
        <div class="col-12 col-lg-7">
            <!-- Single Featured Post -->
            <?php if(count($random_articles)>0): ?>
                <div class="single-blog-post featured-post">
                    <div class="post-thumb">
                        <a href="<?php echo e(URL::to('articles/'.$random_articles[0]['article_type'].'/'.$random_articles[0]['id'])); ?>"><img style="width: 100%; height: 500px" src="/dvon_files/public/uploads/<?php echo e($random_articles[0]['article_intro_image']); ?>" alt=""></a>
                    </div>
                    <div class="post-data">
                        <h4><?php echo e($random_articles[0]['article_title']); ?></h4>
                        <div class="post-meta">
                            <p class="post-author">
                                <a class="text-danger" href="#">
                                    … Read Interview …
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lower-content'); ?>
<div class="popular-news-area section-padding-80-50">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="section-heading">
                    <h6 class="rect-box-headline">Popular Updates</h6>
                </div>

                <div class="row">
                    <!-- Single Post -->
                    <?php $__currentLoopData = $random_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <!-- Single Post -->
                        
                            <?php if($key > 0): ?>
                                <div class="col-12 col-md-6">
                                    <div class="single-blog-post style-3">
                                        
                                        
                                        <div class="post-thumb">
                                            <div class="single-blog-post featured-post mb-30">
                                                <div>
                                                    <a href="<?php echo e(URL::to('articles/'.$article['article_type'].'/'.$article['id'])); ?>"><img style="width: 400px; height: 500px" src="/dvon_files/public/uploads/<?php echo e($article['article_intro_image']); ?>" alt=""></a>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Post -->
                                <div class="col-12 col-md-6">
                                    <div class="single-blog-post style-3">
                                        <div class="post-data">
                                            
                                            <h4><?php echo e($article['article_title']); ?>:</h4>
                                            <div class="text-left row" style="word-break: break-word;">
                                                <?php echo substr($article['article_intro'],0,500)?>...
                                            </div>
                                            
                                            
                                            <p class="post-author">
                                                <a class="text-danger" href="<?php echo e(URL::to('articles/'.$article['article_type'].'/'.$article['id'])); ?>">
                                                    … Read Story here…
                                                </a>
                                            </p>
                                            <div class="align-items-center">
                                                <?php
                                                    function getLikes($article_id){
                                                        $likes = App\Like::where('article_id',$article_id)->get();
                                                        return count($likes);
                                                    }

                                                    function getComments($article_id){
                                                        $comments = App\ArticleComment::where('article_id',$article_id)->get();
                                                        return count($comments);
                                                    }

                                                    function getLikeUser($article_id, $user_id){
                                                        $likes = App\Like::where('user_id',$user_id)->where('article_id',$article_id)->get();
                                                        return count($likes);
                                                    }

                                                    function getCommentUser($article_id, $user_id){
                                                        $likes = App\ArticleComment::where('user_id',$user_id)->where('article_id',$article_id)->get();
                                                        return count($likes);
                                                    }

                                                ?>
                                                <a href="/api/like/<?php echo e($article['id']); ?>" class="<?php echo e($article['id']); ?>" id="like-btn">
                                                    <?php if(Auth::user()): ?>
                                                        <?php if(getLikeUser($article['id'], Auth::user()->id)>0): ?>
                                                            <i style="color: red" id="like-icon" class="fa fa-thumbs-up"></i>
                                                        <?php else: ?>
                                                            <i style="color: gray" id="like-icon" class="fa fa-thumbs-up"></i>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <i style="color: gray" id="like-icon" class="fa fa-thumbs-up"></i>
                                                    <?php endif; ?>
                                                    <span id="likes">
                                                        <?php
                                                            echo getLikes($article['id']);
                                                        ?>
                                                    </span>
                                                </a>
                                                <a href="<?php echo e(URL::to('articles/'.$article['article_type'].'/'.$article['id'])); ?>" class="post-comment">
                                                    <?php if(Auth::user()): ?>
                                                        <?php if(getCommentUser($article['id'], Auth::user()->id)>0): ?>
                                                            <i style="color: red" id="comment-icon" class="fa fa-comments"></i>
                                                        <?php else: ?>
                                                            <i style="color: gray" id="comment-icon" class="fa fa-comments"></i>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <i style="color: gray" id="comment-icon" class="fa fa-comments"></i>
                                                    <?php endif; ?>
                                                    <span id="likes">
                                                        <?php
                                                            echo getComments($article['id']);
                                                        ?>
                                                    </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <?php if(count($random_articles)>1): ?>
                <div class="col-12 col-lg-4">
                    <div class="section-heading">
                        <h6 class="rect-box-headline">Info</h6>
                    </div>
                    <!-- Popular News Widget -->
                    <div class="popular-news-widget mb-30">
                        <h3>4 Most Recent Updates</h3>
                        <?php $__currentLoopData = $latest_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Single Popular Blog -->
                            <div class="single-popular-post">
                                <a href="<?php echo e(URL::to('articles/'.$latest['article_type'].'/'.$latest['id'])); ?>">
                                <h6><span><?php echo e($key + 1); ?>.</span> <?php echo e($latest['article_title']); ?></h6>
                                </a>
                                
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Newsletter Widget -->
                    <div class="newsletter-widget">
                        <h4>Newsletter</h4>
                        <p>Get our latest update by simply Subscribing to our Newsletter</p>
                        <form action="#" method="post">
                            <input type="text" name="text" placeholder="Name">
                            <input type="email" name="email" placeholder="Email">
                            <button type="submit" class="btn w-100">Subscribe</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</div>

<!-- ##### Video Post Area Start ##### -->

<div class="video-post-area bg-img bg-overlay" style="background-image: url(img/bg-img/bg1.jpg);">
    <div class="container">
        <div class="row justify-content-center">
            <!-- Single Video Post -->
            <div class="col-12 col-sm-6 col-md-4">
                
                <div class="single-video-post">
                    <img src="<?php echo e(asset('site/img/bg-img/aunty shade advert.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ##### Video Post Area End ##### -->
<?php if(Auth::user()): ?>
<script>
    var like_btn = document.getElementById('like-btn');
    var like_icon = document.getElementById('like-icon');
    var likes_container = document.getElementById('likes');

    like_btn.onclick = (e) => {
        e.preventDefault()
        var user_id = "<?php echo e(Auth::user()->id); ?>"
        var url = like_btn.href

        var xhr, formData;

        xhr = new XMLHttpRequest();
        xhr.withCredentials = false;
        xhr.open('POST', url);

        xhr.onload = function(){
            var json;

            if(xhr.status != 200){
                console.log('HTTP Error:' + xhr.status);
                return;
            }

            json = JSON.parse(xhr.responseText);

            var res = xhr.responseText;
            var msg = JSON.parse(res).msg;
            var likes = JSON.parse(res).likes;

                if(msg === "liked"){
                    like_icon.style.color = "red";
                    console.log(likes);
                    likes_container.innerText = likes;
                }else if(msg === "unliked"){
                    like_icon.style.color = "gray";
                    console.log(likes);
                    likes_container.innerText = likes;
                }else if(msg === "failure"){
                    alert("Internal error has occurred!");
                }else{
                    alert('connection error')
                }
            
        };

        formData = new FormData();
        formData.append('id', user_id);

        xhr.send(formData);
    }
</script>
<?php else: ?>
<script>
    var like_btn = document.getElementById('like-btn')

    like_btn.onclick = (e) => {
        e.preventDefault()
        alert('Ops!, You can not like article because you are not logged in. Please Login or Register to like article.')
    }
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/site/home.blade.php ENDPATH**/ ?>