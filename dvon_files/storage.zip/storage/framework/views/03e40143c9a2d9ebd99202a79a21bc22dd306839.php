<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h4 class="page-title">Edit Country</h4>
                <h4 class="page-title text-center text-success">
                    <?php if(session('msg')): ?>
                    <?php echo e(session('msg')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            <form action="<?php echo e(url('admin/country/'.$country->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div id="form" class="form-group">
                    </div>
                    <div class="form-group">
                        <label>Country Name</label>
                        <input class="form-control" type="text" name="country_name" value="<?php echo e($country->country_name); ?>">
                    </div>
                    <div class="form-group">
                        <label>Country Code</label>
                        <input class="form-control" type="text" name="country_code" value="<?php echo e($country->country_code); ?>">
                    </div>
                    <div class="m-t-20 text-center">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\DestinyVoiceOfNigeria\resources\views/Admin/Countries/edit-country.blade.php ENDPATH**/ ?>