<?php $__env->startSection('upper-content'); ?>
<?php if(count($article)>0): ?>
    <h3 class="text-center"><?php echo e($article[0]->article_title); ?></h3>
    <div class="article-items">
        <?php echo $article[0]->article_intro;?>
    </div>
    
<?php else: ?>
    <h3 class="text-center">Ops! Article content is unavailable at the moment</h3>
    <h3 class="text-center">Please check again later</h3>
    <img src="<?php echo e(asset('site/img/bg-img/ops.gif')); ?>" alt="">
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('lower-content'); ?>
<?php if(count($article)>0): ?>
    <!-- ##### Blog Area Start ##### -->
    <div class="blog-area section-padding-0-80">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <br>
                    <div class="blog-posts-area">
                        <div class="section-heading">
                            <h6>Interview</h6>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="article-items" style="word-break: break-word">
                                    <?php echo $article[0]->article_description;?>
                                </div>
                                <a href="<?php echo e(URL::to('articles/'.$article_type)); ?>" class="btn btn-primary">
                                … Read Other Related Interviews….
                                </a>
                                <br><br>
                            </div>
                        </div>

                        <!-- Comment Area Start -->
                        

                        <div class="post-a-comment-area section-padding-80-0">
                            <h4>Leave a comment</h4>
                            
                            <!-- Reply Form -->
                            <div class="contact-form-area">
                                <div class="col-12 text-center">
                                    <h4 class="page-title text-center text-success">
                                        <?php if(session('msg')): ?>
                                            <?php echo e(session('msg')); ?>

                                        <?php endif; ?>
                                    </h4>
                                </div>
                                <?php if(Auth::user()): ?>
                                    <form action="<?php echo e(URL::to('articles/'.$article_type.'/'.$article[0]->id.'/comment')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-12">
                                                <textarea name="comment" class="form-control" id="message" cols="30" rows="10" placeholder="Comment" required></textarea>
                                            </div>
                                            <div class="col-12 text-center">
                                                <button class="btn newspaper-btn mt-30 w-100" type="submit">Submit Comment</button>
                                            </div>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(URL::to('articles/'.$article_type.'/'.$article[0]->id.'/comment')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-12 text-center">
                                                <button class="btn newspaper-btn mt-30 w-100" type="submit">Please Login to post comments</button>
                                            </div>
                                        </div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="col-12 col-lg-4">
                    <div class="section-heading">
                        <h6 class="rect-box-headline">Info</h6>
                    </div>
                    <!-- Popular News Widget -->
                    <div class="popular-news-widget mb-30">
                        <h3>4 Most Recent Updates</h3>
                        
                                
                            
                    </div>

                    <!-- Newsletter Widget -->
                    <div class="newsletter-widget">
                        <h4>Newsletter</h4>
                        <p>Get our latest update by simply Subscribing to our Newsletter</p>
                        <form action="#" method="post">
                            <input type="text" name="text" placeholder="Name">
                            <input type="email" name="email" placeholder="Email">
                            <button type="submit" class="btn w-100">Subscribe</button>
                        </form>
                    </div>
                </div>
            
            </div>
        </div>
    </div>
    <!-- ##### Blog Area End ##### -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/site/article-details.blade.php ENDPATH**/ ?>