<?php $__env->startSection('upper-content'); ?>
    <div class="col-12 col-lg-12">
        <h1 style="font-family: OCR A Std; color: #24293c; text-align: center">Ops! Content not found</h1>
        <img src="<?php echo e(asset('site/img/bg-img/page404.gif')); ?>" alt="">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/site/page404.blade.php ENDPATH**/ ?>