<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h4 class="page-title">Edit Advert</h4>
                <h4 class="page-title text-center text-success">
                    <?php if(session('msg')): ?>
                    <?php echo e(session('msg')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
            <form action="<?php echo e(url('admin/adverts/'.$advert->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div id="form" class="form-group"> 
                    <div class="form-group">
                        <span>Please select web pages number</span>
                        <select class="form-control" name="pages" id="pages">
                            <option value="<?php echo e($advert->pages); ?>"><?php echo e($advert->pages); ?></option>
                            <option value="5 pages">5 pages</option>
                            <option value="all pages">all pages</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <span>Active Status</span>
                        <select class="form-control" name="status" id="pages">
                            <option value="<?php echo e($advert->status); ?>"><?php echo e($advert->status); ?></option>
                            <option value="active">Activate</option>
                            <option value="inactive">Inactivate</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Advert Image</label>
                        <span>Select new advert if you to change or leave current one</span>
                        <input class="form-control" id="advert_image" type="file" name="advert_image">
                    <div align="center"><img style="width: 350px; height: 250px" id="preview" src="<?php echo e($advert->advert); ?>" alt="preview" /></div>
                    <input type="hidden" name="expired" value="<?php echo e($advert->expired); ?>">
                    <div class="m-t-20 text-center">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dvon_lunch\dvon_files\resources\views/Admin/Adverts/edit-advert.blade.php ENDPATH**/ ?>