<?php $__env->startSection('upper-content'); ?>

<h3 class="text-center">MEET NIGERIAN ACHIEVERS AT HOME</h3>
<p>
    In continuation with our objective of elevating the image of Nigeria and Nigerians
    across the globe, we bring you a series of rare interviews with ardent lovers of
    Nigeria from Diaspora.
</p>
<p>
    First is the story of “Akeem”, who despite his appreciation of the United States of
    America, where he has been privileged to build his career and obtained “the good
    life”, finds Nigeria to be the only home he longs to retire to one day, God willing.
</p>
<p>
    <h5>Meet Akeem:</h5>
</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('lower-content'); ?>
<?php if($lower): ?>
    <!-- ##### Blog Area Start ##### -->
    <div class="blog-area section-padding-0-80">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <br>
                    <h3 class="text-center">“…. Nigerians have the brains ….”</h3>
                    <div class="blog-posts-area">
                        <div class="section-heading">
                            <h6>Interview</h6>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="post-thumb" style="width: 350px; height: 650px; float: left; margin-right: 30px">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/akeem usa.jpg')); ?>" alt=""></a>
                                </div>
                                <h4 class="text-center">NIGERIAN IN DIASPORA (United States of America)</h4>
                               
                               <h5 class="text-center">Akeem Baruwa</h5>

                               <h6 class="text-left">PLACE OF BIRTH: </h6>
                               <p class="text-left">
                                Osun State, Nigeria.
                               </p>

                               <h6 class="text-left">ACADEMIC QUALIFICATIONS:</h6>
                               <p class="text-left">
                                Over 20 years of Military training and Career
                                at the United States Marine Corps.
                               </p>

                               <h6 class="text-left">PROFESSION / OCCUPATION:</h6>
                               <p class="text-left">
                                U.S Marine Corps (Commissioned Officer).
                               </p>
                               <h6 class="text-left">
                                LOCATION:
                                </h6>
                               <p class="text-left">
                                Career has so far covered USA,
                                Japan, Spain, Italy, France, Germany,
                                Portugal, Australia, Djibouti, Peru, Columbia,
                                Panama, Philippines, Thailand and many
                                other locations.
                               </p>
                               <h6 class="text-left">
                                THOUGHTS ABOUT NIGERIA:
                                </h6>
                               <p class="text-left">
                                Appreciates his humble Nigerian birth,
                                upbringing and growing up experiences.
                               </p>
                               <p class="text-left">
                                He strongly believes the “never gonna give
                                up attitude” acquired while growing up in
                                Nigeria, has been the push factor that has
                                enabled him to rise above the challenges of
                                his career and living in the United States of
                                America.
                               </p>
                               <p class="text-left">
                                Officer Akeem believes Nigeria is always
                                home sweet home and has nothing but love
                                for all Nigerians. He desires to settle back
                                home, upon retirement.
                               </p>
                               <h6 class="text-left">
                                BEST LOCAL FOOD DELICACIES:
                                </h6>
                               <p class="text-left">
                                Amala and Gbegiri (Bean soup), with Goat meat.
                               </p>
                               <h6 class="text-left">
                                GOODWILL MESSAGE TO NIGERIANS:
                                </h6>
                               <p class="text-left">
                                Nigerians have the brain and Nigeria has the
                                potential to be great in the nearest future.
                                Let’s aim for it.
                               </p>

                               <p>….. END …</p>
                            </div>
                            <a href="<?php echo e(URL::to('articles/nigerians-at-home-achievers')); ?>" class="btn btn-primary">
                            … Read Other Interviews….
                            </a>
                        </div>
                        <br><br>
                        <!-- Comment Area Start -->
                        <div class="comment_area clearfix">
                            <h5 class="title">3 Comments</h5>

                            <ol>
                                <!-- Single Comment Area -->
                                <li class="single_comment_area">
                                    <!-- Comment Content -->
                                    <div class="comment-content d-flex">
                                        <!-- Comment Author -->
                                        <div class="comment-author">
                                            <img src="<?php echo e(asset('site/img/bg-img/30.jpg')); ?>" alt="author">
                                        </div>
                                        <!-- Comment Meta -->
                                        <div class="comment-meta">
                                            <a href="#" class="post-author">Christian Williams</a>
                                            <a href="#" class="post-date">April 15, 2018</a>
                                            <p>Donec turpis erat, scelerisque id euismod sit amet, fermentum vel dolor. Nulla facilisi. Sed pellen tesque lectus et accu msan aliquam. Fusce lobortis cursus quam, id mattis sapien.</p>
                                        </div>
                                    </div>
                                    <ol class="children">
                                        <li class="single_comment_area">
                                            <!-- Comment Content -->
                                            <div class="comment-content d-flex">
                                                <!-- Comment Author -->
                                                <div class="comment-author">
                                                    <img src="<?php echo e(asset('site/img/bg-img/31.jpg')); ?>" alt="author">
                                                </div>
                                                <!-- Comment Meta -->
                                                <div class="comment-meta">
                                                    <a href="#" class="post-author">Sandy Doe</a>
                                                    <a href="#" class="post-date">April 15, 2018</a>
                                                    <p>Donec turpis erat, scelerisque id euismod sit amet, fermentum vel dolor. Nulla facilisi. Sed pellen tesque lectus et accu msan aliquam. Fusce lobortis cursus quam, id mattis sapien.</p>
                                                </div>
                                            </div>
                                        </li>
                                    </ol>
                                </li>

                                <!-- Single Comment Area -->
                                <li class="single_comment_area">
                                    <!-- Comment Content -->
                                    <div class="comment-content d-flex">
                                        <!-- Comment Author -->
                                        <div class="comment-author">
                                            <img src="<?php echo e(asset('site/img/bg-img/32.jpg')); ?>" alt="author">
                                        </div>
                                        <!-- Comment Meta -->
                                        <div class="comment-meta">
                                            <a href="#" class="post-author">Christian Williams</a>
                                            <a href="#" class="post-date">April 15, 2018</a>
                                            <p>Donec turpis erat, scelerisque id euismod sit amet, fermentum vel dolor. Nulla facilisi. Sed pellen tesque lectus et accu msan aliquam. Fusce lobortis cursus quam, id mattis sapien.</p>
                                        </div>
                                    </div>
                                </li>
                            </ol>
                        </div>

                        <div class="post-a-comment-area section-padding-80-0">
                            <h4>Leave a comment</h4>
                            
                            <!-- Reply Form -->
                            <div class="contact-form-area">
                                <form action="#" method="post">
                                    <div class="row">
                                        <div class="col-12 col-lg-6">
                                            <input type="text" class="form-control" id="name" placeholder="Name*">
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <input type="email" class="form-control" id="email" placeholder="Email*">
                                        </div>
                                        <div class="col-12">
                                            <input type="text" class="form-control" id="subject" placeholder="Website">
                                        </div>
                                        <div class="col-12">
                                            <textarea name="message" class="form-control" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                        </div>
                                        <div class="col-12 text-center">
                                            <button class="btn newspaper-btn mt-30 w-100" type="submit">Submit Comment</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <div class="blog-sidebar-area">

                        <!-- Latest Posts Widget -->
                        <div class="latest-posts-widget mb-50">

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/19.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Finance</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Pellentesque mattis arcu massa, nec fringilla turpis eleifend id.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/20.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Politics</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Sed a elit euismod augue semper congue sit amet ac sapien.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/21.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Health</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Pellentesque mattis arcu massa, nec fringilla turpis eleifend id.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/22.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Finance</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Augue semper congue sit amet ac sapien. Fusce consequat.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/23.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Travel</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Pellentesque mattis arcu massa, nec fringilla turpis eleifend id.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Featured Post -->
                            <div class="single-blog-post small-featured-post d-flex">
                                <div class="post-thumb">
                                    <a href="#"><img src="<?php echo e(asset('site/img/bg-img/24.jpg')); ?>" alt=""></a>
                                </div>
                                <div class="post-data">
                                    <a href="#" class="post-catagory">Politics</a>
                                    <div class="post-meta">
                                        <a href="#" class="post-title">
                                            <h6>Augue semper congue sit amet ac sapien. Fusce consequat.</h6>
                                        </a>
                                        <p class="post-date"><span>7:00 AM</span> | <span>April 14</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Popular News Widget -->
                        <div class="popular-news-widget mb-50">
                            <h3>4 Most Popular News</h3>

                            <!-- Single Popular Blog -->
                            <div class="single-popular-post">
                                <a href="#">
                                    <h6><span>1.</span> Amet, consectetur adipiscing elit. Nam eu metus sit amet odio sodales.</h6>
                                </a>
                                <p>April 14, 2018</p>
                            </div>

                            <!-- Single Popular Blog -->
                            <div class="single-popular-post">
                                <a href="#">
                                    <h6><span>2.</span> Consectetur adipiscing elit. Nam eu metus sit amet odio sodales placer.</h6>
                                </a>
                                <p>April 14, 2018</p>
                            </div>

                            <!-- Single Popular Blog -->
                            <div class="single-popular-post">
                                <a href="#">
                                    <h6><span>3.</span> Adipiscing elit. Nam eu metus sit amet odio sodales placer. Sed varius leo.</h6>
                                </a>
                                <p>April 14, 2018</p>
                            </div>

                            <!-- Single Popular Blog -->
                            <div class="single-popular-post">
                                <a href="#">
                                    <h6><span>4.</span> Eu metus sit amet odio sodales placer. Sed varius leo ac...</h6>
                                </a>
                                <p>April 14, 2018</p>
                            </div>
                        </div>

                        <!-- Newsletter Widget -->
                        <div class="newsletter-widget mb-50">
                            <h4>Newsletter</h4>
                            <p>Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
                            <form action="#" method="post">
                                <input type="text" name="text" placeholder="Name">
                                <input type="email" name="email" placeholder="Email">
                                <button type="submit" class="btn w-100">Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Blog Area End ##### -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\DestinyVoiceOfNigeria\resources\views/site/article-details-akeem.blade.php ENDPATH**/ ?>