<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-8 col-4">
                <h4 class="page-title text-center text-success">
                    <?php if(session('msg')): ?>
                    <?php echo e(session('msg')); ?>

                    <?php endif; ?>
                </h4>
                <h4 class="page-title text-center text-danger">
                    <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                    <?php endif; ?>
                </h4>
            <h4 class="page-title">Articles: <?php echo e($article_type); ?></h4>
            </div>
            <div class="col-sm-4 col-8 text-right m-b-30">
                <a class="btn btn-primary btn-rounded float-right" href="<?php echo e(route('article.create')); ?>"><i class="fa fa-plus"></i> Add Article</a>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="article grid-article">
                    <div class="article-image" style="height: 300px">
                    <a href="<?php echo e(url('admin/article/'.$article->id.'/edit')); ?>"><img style="width:300xp; height: 300px" class="img-fluid" src="/storage/uploads/<?php echo e($article->article_intro_image); ?>" alt=""></a>
                    </div>
                    <div class="article-content">
                        <h3 class="article-title"><a href="<?php echo e(url('admin/article/'.$article->id.'/edit')); ?>"><?php echo e($article->article_title); ?></a></h3>
                    <p style="word-break: break-word"><?php echo substr($article->article_intro,0,50) ?>...</p>
                        <div class="article-info clearfix">
                            <div class="article-left">
                                <a class="dropdown-item" href="<?php echo e(url('admin/article/'.$article->id.'/edit')); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                <a data-toggle="modal" class="dropdown-item" data-target="#delete_department" href="<?php echo e(url('admin/article/'.$article->id.'/')); ?>"
                                    onclick="event.preventDefault();"><i class="fa fa-trash-o m-r-5"></i>
                                    <?php echo e(__('delete')); ?>

                                </a>

                                <form id="delete-form" action="<?php echo e(url('admin/article/'.$article->id.'/')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div><?php echo e($articles->links()); ?></div>
    </div>
</div>

<div id="delete_department" class="modal fade delete-modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <img src="assets/img/sent.png" alt="" width="50" height="46">
                <h3>Are you sure want to delete this Appointment?</h3>
                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                    <button type="submit" class="btn btn-danger"
                    onclick="
                    document.getElementById('delete-form').submit();"
                    >Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\DestinyVoiceOfNigeria\resources\views/Admin/Article/article-dashboard.blade.php ENDPATH**/ ?>